# train_model.py
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

def train_model(data_path='data/sample_transactions.csv'):
    df = pd.read_csv(data_path)
    X = df.drop('fraud', axis=1)
    y = df['fraud']
    model = RandomForestClassifier()
    model.fit(X, y)
    joblib.dump(model, 'model/fraud_model.joblib')
    print("Model saved to model/fraud_model.joblib")

if __name__ == "__main__":
    train_model()