# lambda_handler.py
import joblib
import json

model = joblib.load('/opt/fraud_model.joblib')

def lambda_handler(event, context):
    transaction = event['transaction']
    prediction = model.predict([transaction])
    return {
        'statusCode': 200,
        'body': json.dumps({'fraud_prediction': int(prediction[0])})
    }