# Credit Card Fraud Detection Project

This project uses Python and AWS to build a serverless credit card fraud detection pipeline.

## Components
- Model training: `model/train_model.py`
- Lambda function: `lambda_function/lambda_handler.py`
- Data ingestion: `scripts/data_ingestion.py`

## How to run
1. Train the model: `python model/train_model.py`
2. Deploy Lambda function
3. Upload test transactions and invoke Lambda